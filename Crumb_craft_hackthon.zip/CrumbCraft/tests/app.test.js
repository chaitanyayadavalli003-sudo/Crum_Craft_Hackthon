const test = require("node:test");
const assert = require("node:assert/strict");
const { calculatePrice, capacity, BOM } = require("../server");
const db = require("../data/db.json");
test("catalog contains ten flavors and five frostings",()=>{assert.equal(db.flavors.length,10);assert.equal(db.frostings.length,5)});
test("price calculator returns valid non-negative values",()=>{const p=calculatePrice({weight:2,flavor:"red-velvet",frosting:"fondant",date:"2026-12-24",decoration:true},db);assert.ok(p.total>0);assert.ok(p.subtotal>=p.total);assert.equal(typeof p.earlyBird,"boolean")});
test("price calculator rejects weight outside allowed range",()=>{assert.throws(()=>calculatePrice({weight:6,flavor:"vanilla",frosting:"buttercream"},db),/0.5kg and 5kg/)});
test("capacity counts only non-cancelled orders",()=>{const c=capacity(db,"2026-12-24");assert.equal(c.booked,15);assert.equal(c.limit,25);assert.equal(c.remaining,10)});
test("BOM recipe exists for every catalog flavor",()=>{for(const f of db.flavors)assert.ok(BOM[f.id])});
test("every flavor has a positive multiplier and a non-negative add-on",()=>{
  for(const f of db.flavors){assert.ok(f.multiplier>0);assert.ok(f.addon>=0);}
});
test("invalid flavor and frosting are rejected",()=>{
  assert.throws(()=>calculatePrice({weight:1,flavor:"not-real",frosting:"buttercream"},db),/valid flavor and frosting/);
});
test("price is deterministic for the same configuration",()=>{
  const c={weight:1.5,flavor:"vanilla",frosting:"buttercream",date:"2026-11-21",decoration:false};
  assert.deepEqual(calculatePrice(c,db),calculatePrice(c,db));
});

test("capacity percentage is bounded and excludes cancelled orders",()=>{
 const fixture={capacityPerDay:10,orders:[
  {date:"2026-12-24",status:"Confirmed"},
  {date:"2026-12-24",status:"Cancelled"},
  {date:"2026-12-24",status:"Preparing"}
 ]};
 const c=capacity(fixture,"2026-12-24");
 assert.equal(c.booked,2);assert.equal(c.remaining,8);assert.equal(c.percent,20);
});

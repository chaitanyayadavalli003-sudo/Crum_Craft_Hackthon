const $=id=>document.getElementById(id);
const state={catalog:null,flavor:"chocolate-truffle",lastOrder:null,photoName:""};
const money=n=>"₹ "+Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2});
const escapeHTML=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url,options={}){const token=sessionStorage.getItem("crumbcraftToken");const headers={"Content-Type":"application/json",...(token?{Authorization:"Bearer "+token}:{}),...(options.headers||{})};const r=await fetch(url,{...options,headers});const data=await r.json();if(!r.ok)throw new Error(data.error||"Something went wrong.");return data}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),3200)}
function formData(){return {customer:$("customer").value,weight:Number($("weight").value),flavor:state.flavor,shape:$("shape").value,frosting:$("frosting").value,message:$("message").value,decoration:$("decoration").checked,date:$("date").value,slot:$("slot").value,photoName:state.photoName}}
function renderCatalog(){
 $("flavorOptions").innerHTML=state.catalog.flavors.map(f=>`<button type="button" class="flavor-option ${f.id===state.flavor?"active":""}" data-flavor="${f.id}">${escapeHTML(f.name)}<span>${f.multiplier.toFixed(2)}× flavour profile</span></button>`).join("");
 $("frosting").innerHTML=state.catalog.frostings.map(f=>`<option value="${f.id}">${escapeHTML(f.name)}${f.fee?` (+${money(f.fee)})`:""}</option>`).join("");
 $("flavorOptions").addEventListener("click",e=>{const b=e.target.closest("[data-flavor]");if(!b)return;state.flavor=b.dataset.flavor;document.querySelectorAll(".flavor-option").forEach(x=>x.classList.toggle("active",x.dataset.flavor===state.flavor));updatePrice()});
}
async function updatePrice(){
 $("weightOutput").textContent=Number($("weight").value).toFixed(1)+" kg";
 const f=state.catalog.flavors.find(x=>x.id===state.flavor), frost=state.catalog.frostings.find(x=>x.id===$("frosting").value);
 $("previewFlavor").textContent=f.name;$("previewDetails").textContent=`${Number($("weight").value).toFixed(1)} kg · ${frost.name}`;$("previewShape").textContent=$("shape").value.toUpperCase()+" CAKE";
 try{const p=await api("/api/price",{method:"POST",body:JSON.stringify(formData())});$("priceTotal").textContent=money(p.total);$("subtotal").textContent=money(p.subtotal);$("discount").textContent="− "+money(p.discount);$("totalBottom").textContent=money(p.total);$("discountNote").textContent=p.earlyBird?"Lovely! Your 10% early-bird discount is applied.":"Book 7+ days ahead to unlock 10% off."}catch(e){toast(e.message)}
}
async function updateCapacity(){const date=$("date").value;if(!date)return;$("capacityInfo").textContent="Checking availability…";try{const c=await api("/api/capacity/"+date);$("capacityInfo").textContent=c.remaining?`${c.booked}/${c.limit} cakes booked · ${c.remaining} slots available (${c.percent}% full)`:"This date is fully booked. Please choose another day."}catch(e){$("capacityInfo").textContent=e.message}}
async function loadPlanner(){
 const date=$("plannerDate").value;if(!date)return;
 try{const [f,o]=await Promise.all([api("/api/forecast/"+date),api("/api/orders?date="+date)]);
 $("statOrders").textContent=f.orderCount;$("statCapacity").textContent=f.capacity.limit;$("statRemaining").textContent=f.capacity.remaining;$("statPercent").textContent=f.capacity.percent+"%";
 $("progressFill").style.width=f.capacity.percent+"%";$("progressBooked").textContent=f.orderCount+" cakes booked";$("progressRemaining").textContent=f.capacity.remaining+" slots remaining";$("capacityBadge").textContent=f.capacity.percent>=100?"Fully booked":f.capacity.percent>=80?"Almost full":"Taking orders";
 $("ingredientList").innerHTML=f.ingredients.length?f.ingredients.map(i=>`<div class="ingredient-row"><span>${escapeHTML(i.name)}</span><span>${i.kg.toFixed(2)} kg</span></div>`).join():"<p class='hint'>No active orders for this date yet.</p>";
 $("recentOrders").innerHTML=o.length?o.slice(0,10).map(order=>`<div class="order-row"><div><b>${escapeHTML(order.customer)} · ${escapeHTML(order.id)}</b><small>${order.weight}kg ${escapeHTML(order.flavor)} · ${escapeHTML(order.slot)}</small></div><div><span class="status ${escapeHTML(order.status)}">${escapeHTML(order.status)}</span><select aria-label="Update status for ${escapeHTML(order.id)}" data-status="${escapeHTML(order.id)}"><option ${order.status==="Confirmed"?"selected":""}>Confirmed</option><option ${order.status==="Preparing"?"selected":""}>Preparing</option><option ${order.status==="Ready for Pickup"?"selected":""}>Ready for Pickup</option><option ${order.status==="Completed"?"selected":""}>Completed</option><option ${order.status==="Cancelled"?"selected":""}>Cancelled</option></select></div></div>`).join():"<p class='hint'>No orders for this date.</p>";
 }catch(e){toast(e.message)}
}
function receipt(order){
 const flavor=state.catalog.flavors.find(x=>x.id===order.flavor)?.name||order.flavor;
 const frost=state.catalog.frostings.find(x=>x.id===order.frosting)?.name||order.frosting;
 $("receiptContent").innerHTML=`<span class="eyebrow">CRUMBCRAFT · DIGITAL RECEIPT</span><h2>Thank you, ${escapeHTML(order.customer)}!</h2><p>Your cake order is confirmed. We can’t wait to make your celebration sweeter.</p><div class="receipt-line"><span>Order ID</span><b>${escapeHTML(order.id)}</b></div><div class="receipt-line"><span>Pickup date</span><b>${escapeHTML(order.date)}</b></div><div class="receipt-line"><span>Pickup time</span><b>${escapeHTML(order.slot)}</b></div><div class="receipt-line"><span>Cake</span><b>${order.weight}kg ${escapeHTML(flavor)}</b></div><div class="receipt-line"><span>Shape / Frosting</span><b>${escapeHTML(order.shape)} / ${escapeHTML(frost)}</b></div><div class="receipt-line"><span>Icing message</span><b>${escapeHTML(order.message||"—")}</b></div><div class="receipt-line"><span>Status</span><b>${escapeHTML(order.status)}</b></div><div class="receipt-line"><span>Total estimate</span><b>${money(order.price?.total||0)}</b></div><p>Thank you for choosing CrumbCraft. Please keep your order ID for reference.</p>`;
 $("receiptModal").classList.add("open");$("receiptModal").setAttribute("aria-hidden","false");
}
$("cakeForm").addEventListener("input",updatePrice);$("cakeForm").addEventListener("change",()=>{updatePrice();updateCapacity()});
$("cakeForm").addEventListener("submit",async e=>{e.preventDefault();if(!$("cakeForm").reportValidity())return;try{const result=await api("/api/orders",{method:"POST",body:JSON.stringify(formData())});state.lastOrder=result.order;receipt(result.order);toast("Your cake order is confirmed!");await updateCapacity();$("plannerDate").value=result.order.date;loadPlanner()}catch(err){toast(err.message)}});
$("photo").addEventListener("change",async e=>{
 const file=e.target.files[0];if(!file)return;
 if(file.size>4*1024*1024){toast("Please choose an image smaller than 4MB.");e.target.value="";return}
 if(!["image/jpeg","image/png","image/webp"].includes(file.type)){toast("Only JPG, PNG and WebP images are allowed.");e.target.value="";return}
 const localUrl=URL.createObjectURL(file);$("photoPreview").innerHTML="";
 const img=document.createElement("img");img.alt="Cake photo upload preview";img.src=localUrl;$("photoPreview").append(img);
 const body=new FormData();body.append("photo",file);
 try{const r=await fetch("/api/upload",{method:"POST",body});const data=await r.json();if(!r.ok)throw new Error(data.error||"Upload failed.");state.photoName=data.photoName;state.photoUrl=data.photoUrl;toast("Photo uploaded successfully.");}
 catch(err){state.photoUrl="";toast(err.message);}
});
$("lookupBtn").addEventListener("click",async()=>{const id=$("orderLookup").value.trim();if(!id)return toast("Enter an order ID first.");try{const order=await api("/api/orders/"+encodeURIComponent(id));receipt(order)}catch(e){toast(e.message)}});
$("orderLookup").addEventListener("keydown",e=>{if(e.key==="Enter")$("lookupBtn").click()});
$("plannerDate").addEventListener("change",loadPlanner);$("refreshPlanner").addEventListener("click",loadPlanner);
$("recentOrders").addEventListener("change",async e=>{const id=e.target.dataset.status;if(!id)return;try{await api("/api/orders/"+id+"/status",{method:"PATCH",body:JSON.stringify({status:e.target.value})});toast("Order status updated.");loadPlanner()}catch(err){toast(err.message)}});
$("supplierBtn").addEventListener("click",async()=>{try{const p=await api("/api/supplier-order/"+$("plannerDate").value);$("supplierResult").innerHTML=`<div class="supplier-box"><b>${escapeHTML(p.supplierOrderId)}</b><br>Purchase list for ${escapeHTML(p.date)}<br>${p.lines.map(x=>`${escapeHTML(x.ingredient)}: ${x.requiredKg.toFixed(2)} kg`).join("<br>")}<br><button class="secondary" id="printPO">Print / Save as PDF</button></div>`;$("printPO").addEventListener("click",()=>{const w=window.open("","_blank");if(!w)return toast("Allow pop-ups to print the purchase order.");w.document.write(`<h1>CrumbCraft Supplier Purchase Order</h1><p>${escapeHTML(p.supplierOrderId)} · ${escapeHTML(p.date)}</p><table border="1" cellpadding="8"><tr><th>Ingredient</th><th>Required (kg)</th></tr>${p.lines.map(x=>`<tr><td>${escapeHTML(x.ingredient)}</td><td>${x.requiredKg.toFixed(2)}</td></tr>`).join("")}</table><script>window.onload=()=>window.print()<\/script>`);w.document.close()})}catch(e){toast(e.message)}});
$("closeReceipt").addEventListener("click",()=>{$("receiptModal").classList.remove("open");$("receiptModal").setAttribute("aria-hidden","true")});$("receiptModal").addEventListener("click",e=>{if(e.target===$("receiptModal"))$("closeReceipt").click()});$("printReceipt").addEventListener("click",()=>window.print());

$("bakerLoginForm").addEventListener("submit",async e=>{
 e.preventDefault();const message=$("bakerLoginMessage");message.textContent="Signing in…";
 try{const result=await api("/api/auth/login",{method:"POST",body:JSON.stringify({username:$("bakerUsername").value,password:$("bakerPassword").value})});
 sessionStorage.setItem("crumbcraftToken",result.token);$("bakerPassword").value="";$("bakerLogin").hidden=true;$("bakerDashboard").hidden=false;$("bakerWelcome").textContent="Signed in as "+result.username;await loadPlanner();
 }catch(err){message.textContent=err.message;}
});
$("bakerLogout").addEventListener("click",()=>{sessionStorage.removeItem("crumbcraftToken");$("bakerDashboard").hidden=true;$("bakerLogin").hidden=false;$("recentOrders").innerHTML="";});

async function init(){try{state.catalog=await api("/api/catalog");renderCatalog();const today=new Date(),min=today.toISOString().slice(0,10);$("date").min=min;$("plannerDate").value="2026-12-24";$("date").value="2026-12-24";$("frosting").value="buttercream";await updatePrice();await updateCapacity();if(sessionStorage.getItem("crumbcraftToken")){try{const me=await api("/api/auth/me");$("bakerLogin").hidden=true;$("bakerDashboard").hidden=false;$("bakerWelcome").textContent="Signed in as "+me.username;await loadPlanner()}catch(e){sessionStorage.removeItem("crumbcraftToken")}}}catch(e){toast("Could not connect to the server. Please restart the app.")}}
init();
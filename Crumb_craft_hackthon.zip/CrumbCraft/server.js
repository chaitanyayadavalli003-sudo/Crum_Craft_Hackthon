const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const multer = require("multer");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const pino = require("pino");

const app = express();
const PORT = process.env.PORT || 3000;
const logger = pino({ level: process.env.LOG_LEVEL || "info" });
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "crumbcraft.sqlite");
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(DB_FILE);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
 CREATE TABLE IF NOT EXISTS flavors (id TEXT PRIMARY KEY, name TEXT NOT NULL, multiplier REAL NOT NULL, addon REAL NOT NULL);
 CREATE TABLE IF NOT EXISTS frostings (id TEXT PRIMARY KEY, name TEXT NOT NULL, fee REAL NOT NULL);
 CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, customer TEXT NOT NULL, date TEXT NOT NULL, slot TEXT NOT NULL, weight REAL NOT NULL, flavor TEXT NOT NULL, shape TEXT NOT NULL, frosting TEXT NOT NULL, message TEXT, decoration INTEGER NOT NULL DEFAULT 0, photoName TEXT, photoUrl TEXT, status TEXT NOT NULL, price TEXT, createdAt TEXT NOT NULL);
 CREATE INDEX IF NOT EXISTS idx_orders_date ON orders(date);
 CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, passwordHash TEXT NOT NULL, createdAt TEXT NOT NULL);
`);
const seedFile = path.join(DATA_DIR, "db.json");
if (db.prepare("SELECT COUNT(*) AS n FROM flavors").get().n === 0 && fs.existsSync(seedFile)) {
 const seed = JSON.parse(fs.readFileSync(seedFile, "utf8"));
 const insertFlavor = db.prepare("INSERT INTO flavors VALUES (@id,@name,@multiplier,@addon)");
 const insertFrosting = db.prepare("INSERT INTO frostings VALUES (@id,@name,@fee)");
 const insertOrder = db.prepare(`INSERT INTO orders (id,customer,date,slot,weight,flavor,shape,frosting,message,decoration,status,createdAt) VALUES (@id,@customer,@date,@slot,@weight,@flavor,@shape,@frosting,@message,@decoration,@status,@createdAt)`);
 const tx = db.transaction(() => {
  for (const flavor of seed.flavors) insertFlavor.run(flavor);
  for (const frosting of seed.frostings) insertFrosting.run(frosting);
  seed.orders.forEach(o => insertOrder.run({...o, decoration:o.decoration?1:0}));
 });
 tx();
 logger.info("Migrated existing JSON catalogue and orders into SQLite");
}
const capacityPerDay = 25;
const money = n => Math.round(n * 100) / 100;
const getCatalog = () => ({flavors:db.prepare("SELECT * FROM flavors").all(), frostings:db.prepare("SELECT * FROM frostings").all(), capacityPerDay});
const getOrders = () => db.prepare("SELECT * FROM orders").all().map(o=>({...o,decoration:!!o.decoration,price:o.price?JSON.parse(o.price):null}));
const BOM = {
 "chocolate-truffle":{"Flour":400,"Sugar":250,"Whipping Cream":350,"Dark Chocolate":300,"Butter":120},
 "red-velvet":{"Flour":420,"Sugar":280,"Whipping Cream":300,"Cocoa":80,"Butter":140},
 "mango":{"Flour":400,"Sugar":240,"Whipping Cream":300,"Mango Pulp":250,"Butter":120},
 "black-forest":{"Flour":400,"Sugar":260,"Whipping Cream":350,"Dark Chocolate":180,"Butter":120},
 "vanilla":{"Flour":420,"Sugar":250,"Whipping Cream":280,"Butter":150},
 "butterscotch":{"Flour":410,"Sugar":260,"Whipping Cream":300,"Butterscotch Crunch":120,"Butter":130},
 "strawberry":{"Flour":400,"Sugar":250,"Whipping Cream":300,"Strawberry Pulp":220,"Butter":120},
 "coffee":{"Flour":410,"Sugar":250,"Whipping Cream":320,"Coffee":60,"Butter":130},
 "lemon":{"Flour":420,"Sugar":240,"Whipping Cream":280,"Lemon Zest":35,"Butter":130},
 "pistachio":{"Flour":400,"Sugar":250,"Whipping Cream":320,"Pistachio":180,"Butter":120}
};
function calculatePrice(c, catalog=getCatalog()) {
 const flavor=catalog.flavors.find(x=>x.id===c.flavor), frosting=catalog.frostings.find(x=>x.id===c.frosting);
 if(!flavor||!frosting) throw Error("Choose a valid flavor and frosting.");
 const weight=Number(c.weight);
 if(!Number.isFinite(weight)||weight<.5||weight>5) throw Error("Cake weight must be between 0.5kg and 5kg.");
 const base=Math.round(650*weight*100), flav=Math.round((flavor.addon+650*weight*(flavor.multiplier-1))*100);
 const subtotal=base+flav+Math.round(frosting.fee*100)+(c.decoration?18000:0);
 const date=c.date?new Date(c.date+"T12:00:00"):null, days=date?Math.ceil((date-new Date())/86400000):0;
 const discount=days>=7?Math.round(subtotal*.1):0;
 return {subtotal:subtotal/100,discount:discount/100,total:(subtotal-discount)/100,earlyBird:discount>0};
}
function capacity(date) {
 const booked=db.prepare("SELECT COUNT(*) n FROM orders WHERE date=? AND status!='Cancelled'").get(date).n;
 return {date,booked,limit:capacityPerDay,remaining:Math.max(0,capacityPerDay-booked),percent:Math.min(100,Math.round(booked/capacityPerDay*100))};
}
app.use(helmet({crossOriginResourcePolicy:{policy:"cross-origin"}}));
app.use(express.json({limit:"1mb"}));
app.use("/api/",rateLimit({windowMs:15*60*1000,limit:300,standardHeaders:"draft-7",legacyHeaders:false}));
const uploadDir=path.join(__dirname,"public","uploads"); fs.mkdirSync(uploadDir,{recursive:true});
const imageUpload=multer({storage:multer.diskStorage({destination:uploadDir,filename:(req,file,cb)=>cb(null,crypto.randomBytes(12).toString("hex")+path.extname(file.originalname).toLowerCase())}),limits:{fileSize:4*1024*1024,files:1},fileFilter:(req,file,cb)=>["image/jpeg","image/png","image/webp"].includes(file.mimetype)?cb(null,true):cb(Error("Only JPG, PNG and WebP images are allowed."))});
app.use(express.static(path.join(__dirname,"public")));
const JWT_SECRET=process.env.JWT_SECRET||crypto.randomBytes(48).toString("hex");
function requireAuth(req,res,next) {
 const token=(req.headers.authorization||"").replace(/^Bearer\s+/i,"");
 try { if(!token) throw Error(); req.user=jwt.verify(token,JWT_SECRET); next(); }
 catch { res.status(401).json({error:"Baker login required. Please sign in."}); }
}
const loginLimiter=rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:"draft-7",legacyHeaders:false,message:{error:"Too many login attempts. Try again later."}});
app.post("/api/auth/login",loginLimiter,async(req,res)=>{
 const username=String(req.body.username||"").trim(), password=String(req.body.password||"");
 const user=db.prepare("SELECT * FROM users WHERE username=?").get(username);
 if(!user||!(await bcrypt.compare(password,user.passwordHash))) { logger.warn({username},"Baker login failed"); return res.status(401).json({error:"Invalid username or password."}); }
 logger.info({userId:user.id},"Baker logged in");
 res.json({token:jwt.sign({sub:user.id,username:user.username},JWT_SECRET,{expiresIn:"8h"}),username:user.username,expiresIn:28800});
});
app.get("/api/auth/me",requireAuth,(req,res)=>res.json({username:req.user.username}));
app.post("/api/auth/change-password",requireAuth,async(req,res)=>{
 const password=String(req.body.password||"");
 if(password.length<12) return res.status(400).json({error:"Use a password with at least 12 characters."});
 db.prepare("UPDATE users SET passwordHash=? WHERE id=?").run(await bcrypt.hash(password,12),req.user.sub);
 logger.info({userId:req.user.sub},"Baker password changed"); res.json({ok:true});
});
app.post("/api/upload",(req,res)=>imageUpload.single("photo")(req,res,err=>{
 if(err)return res.status(400).json({error:err.code==="LIMIT_FILE_SIZE"?"Image must be 4MB or smaller.":err.message});
 if(!req.file)return res.status(400).json({error:"Choose an image to upload."});
 res.status(201).json({photoName:req.file.originalname.slice(0,100),photoUrl:"/uploads/"+req.file.filename});
}));
app.get("/api/health",(req,res)=>res.json({ok:true,service:"CrumbCraft API",timestamp:new Date().toISOString()}));
app.get("/api/catalog",(req,res)=>res.json(getCatalog()));
app.post("/api/price",(req,res)=>{try{res.json(calculatePrice(req.body));}catch(e){res.status(400).json({error:e.message});}});
app.get("/api/capacity/:date",(req,res)=>/^\d{4}-\d{2}-\d{2}$/.test(req.params.date)?res.json(capacity(req.params.date)):res.status(400).json({error:"Invalid date"}));
app.get("/api/orders/:id",(req,res)=>{const o=getOrders().find(x=>x.id.toLowerCase()===String(req.params.id).toLowerCase());o?res.json(o):res.status(404).json({error:"Order not found."});});
app.get("/api/orders",requireAuth,(req,res)=>{const list=getOrders().filter(o=>!req.query.date||o.date===req.query.date);res.json(list.sort((a,b)=>b.createdAt.localeCompare(a.createdAt)));});
app.post("/api/orders",(req,res)=>{
 try{
  const b=req.body, customer=String(b.customer||"").trim();
  if(customer.length<2)return res.status(400).json({error:"Enter customer name (at least 2 characters)."});
  if(!b.date||!/^\d{4}-\d{2}-\d{2}$/.test(b.date))return res.status(400).json({error:"Choose a valid pickup date."});
  const selected=new Date(b.date+"T23:59:59"); if(Number.isNaN(selected.getTime())||selected<new Date(new Date().toDateString()))return res.status(400).json({error:"Pickup date must be today or later."});
  if(capacity(b.date).remaining<=0)return res.status(409).json({error:"Sorry, this date is fully booked. Please choose another date."});
  const price=calculatePrice(b), id="CC"+crypto.randomBytes(3).toString("hex").toUpperCase();
  const order={id,customer:customer.slice(0,70),date:b.date,slot:b.slot||"10:00 AM",weight:Number(b.weight),flavor:b.flavor,shape:b.shape||"Round",frosting:b.frosting,message:String(b.message||"").slice(0,80),decoration:!!b.decoration,photoName:String(b.photoName||"").slice(0,100),photoUrl:String(b.photoUrl||"").startsWith("/uploads/")?String(b.photoUrl).slice(0,160):"",status:"Confirmed",price,createdAt:new Date().toISOString()};
  db.prepare(`INSERT INTO orders (id,customer,date,slot,weight,flavor,shape,frosting,message,decoration,photoName,photoUrl,status,price,createdAt) VALUES (@id,@customer,@date,@slot,@weight,@flavor,@shape,@frosting,@message,@decoration,@photoName,@photoUrl,@status,@price,@createdAt)`).run({...order,decoration:order.decoration?1:0,price:JSON.stringify(price)});
  logger.info({orderId:id,date:b.date},"Cake order created"); res.status(201).json({order,capacity:capacity(b.date)});
 }catch(e){logger.error({err:e},"Order creation failed");res.status(400).json({error:e.message});}
});
app.patch("/api/orders/:id/status",requireAuth,(req,res)=>{
 const allowed=["Confirmed","Preparing","Ready for Pickup","Completed","Cancelled"];
 if(!allowed.includes(req.body.status))return res.status(400).json({error:"Invalid status."});
 const result=db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);
 if(!result.changes)return res.status(404).json({error:"Order not found."});
 logger.info({orderId:req.params.id,status:req.body.status},"Order status updated");
 res.json(getOrders().find(o=>o.id===req.params.id));
});
app.get("/api/forecast/:date",requireAuth,(req,res)=>{
 const orders=getOrders().filter(o=>o.date===req.params.date&&o.status!=="Cancelled"), totals={};
 for(const o of orders)for(const [ingredient,g] of Object.entries(BOM[o.flavor]||BOM.vanilla))totals[ingredient]=(totals[ingredient]||0)+g*o.weight;
 res.json({date:req.params.date,orderCount:orders.length,capacity:capacity(req.params.date),ingredients:Object.entries(totals).map(([name,g])=>({name,grams:Math.round(g),kg:money(g/1000)})).sort((a,b)=>b.grams-a.grams)});
});
app.get("/api/supplier-order/:date",requireAuth,(req,res)=>{
 const orders=getOrders().filter(o=>o.date===req.params.date&&o.status!=="Cancelled"), totals={};
 for(const o of orders)for(const [name,g] of Object.entries(BOM[o.flavor]||BOM.vanilla))totals[name]=(totals[name]||0)+g*o.weight;
 res.json({supplierOrderId:"PO-"+req.params.date.replaceAll("-",""),date:req.params.date,generatedAt:new Date().toISOString(),lines:Object.entries(totals).map(([ingredient,g])=>({ingredient,requiredKg:money(g/1000)}))});
});
app.use((err,req,res,next)=>{logger.error({err},"Unhandled request error");res.status(500).json({error:"Unexpected server error."});});
if(require.main===module){
 const username=process.env.ADMIN_USERNAME||"baker";
 if(db.prepare("SELECT COUNT(*) n FROM users").get().n===0){
  const password=process.env.ADMIN_PASSWORD||crypto.randomBytes(12).toString("base64url");
  db.prepare("INSERT INTO users(username,passwordHash,createdAt) VALUES(?,?,?)").run(username,bcrypt.hashSync(password,12),new Date().toISOString());
  logger.warn({username,temporaryPassword:password},"Initial baker account created. Change this password after first login.");
 }
 app.listen(PORT,()=>logger.info({port:PORT},"CrumbCraft server started"));
}
module.exports={calculatePrice,capacity:(data,date)=>{if(Array.isArray(data?.orders)){const booked=data.orders.filter(o=>o.date===date&&o.status!=="Cancelled").length,limit=data.capacityPerDay;return {date,booked,limit,remaining:Math.max(0,limit-booked),percent:Math.min(100,Math.round(booked/limit*100))};}return capacity(date);},BOM};

# CrumbCraft v2.0 — Secure Bakery Ordering & Planning

## Improvements
- Baker dashboard protected by JWT authentication (8-hour tokens).
- Passwords hashed with bcryptjs; login attempts are rate-limited.
- SQLite persistence with WAL mode and one-time import from the original `data/db.json`.
- Structured JSON logs using Pino.
- Protected order-list, order-status, forecast and supplier-order APIs.
- Public exact order-ID lookup remains available to customers.
- Existing cake customizer, pricing, capacity, BOM forecast and image validation are retained.

## Requirements
Node.js 18 or newer and npm.

## Run locally
1. Extract the ZIP and open a terminal in the `CrumbCraft` folder.
2. Run `npm install`.
3. Run `npm start`.
4. Open http://localhost:3000.

On first startup, the app creates a baker account. Username defaults to `baker`; a strong temporary password is generated and printed once in the server terminal. Sign in at the Baker dashboard and change the temporary password immediately.

To set initial credentials before the first start, configure:
- `ADMIN_USERNAME` — initial baker username
- `ADMIN_PASSWORD` — initial password (at least 12 characters)
- `JWT_SECRET` — long random token-signing secret
- `PORT` — optional port (default 3000)
- `LOG_LEVEL` — optional Pino log level (default `info`)

PowerShell example:
```powershell
$env:ADMIN_USERNAME="baker"
$env:ADMIN_PASSWORD="Use-A-Long-Unique-Password"
$env:JWT_SECRET="replace-with-a-long-random-secret"
npm start
```

## Change password
After signing in, use an API client or browser console:
```js
fetch("/api/auth/change-password", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Authorization": "Bearer " + sessionStorage.getItem("crumbcraftToken")
  },
  body: JSON.stringify({ password: "A-New-Long-Unique-Password" })
});
```
Password must contain at least 12 characters.

## API
Public: `GET /api/health`, `GET /api/catalog`, `POST /api/price`, `GET /api/capacity/:date`, `POST /api/upload`, `POST /api/orders`, `GET /api/orders/:id`.

Baker login required (`Authorization: Bearer <token>`): `GET /api/auth/me`, `POST /api/auth/change-password`, `GET /api/orders`, `PATCH /api/orders/:id/status`, `GET /api/forecast/:date`, `GET /api/supplier-order/:date`.

## Data migration
First startup imports the included JSON catalogue and demo orders into `data/crumbcraft.sqlite` if the SQLite catalogue is empty. SQLite is the live data store thereafter. Back up this database before upgrades or deployments.

## Tests
Run `npm test`.

## Deployment
Use HTTPS, configure a persistent high-entropy `JWT_SECRET`, set a strong initial password, back up SQLite, and keep dependencies updated. For multi-instance/high-traffic deployment, prefer PostgreSQL. Never commit real credentials or production customer data.
